library(testthat)
library(Golexx)

test_check("Golexx")
