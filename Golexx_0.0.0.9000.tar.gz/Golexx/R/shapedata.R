#' shape data
#'
#' A dataset containing Shape data in Nigeria MAP
#'
#' @format A shape file, with 37 rows and about 7 columns including the statename, capital, multipolygon data
#' @source \url{IITA: Breeding Program}
"shapedata"
