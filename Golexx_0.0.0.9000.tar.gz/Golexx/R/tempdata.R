#' Temperature data
#'
#' A dataset containing precipitation data in Nigeria
#'
#' @format A shape file, with longitude,latitude and layers
#' @source \url{IITA: Breeding Program}
"tempdata"
